<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * EpicJungle Cookie Consent
 */
class EpicJungle_Cookie_Consent {

	/**
	 * The single instance of the class
	 *
	 * @var EpicJungle_Cookie_Consent|null
	 */
	protected static $_instance = null;

	/**
	 * Instance
	 *
	 * @return EpicJungle_Cookie_Consent
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Set Developer Mode Constant.
		if ( ! defined( 'EJCC_DEV_MODE' ) ) {
			define( 'EJCC_DEV_MODE', apply_filters( 'ejcc_dev_mode', false ) );
		}

		// Set the plugin path.
		$this->plugin_path = untrailingslashit( plugin_dir_path( __FILE__ ) );

		// Set the plugin URL.
		$this->plugin_url = untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ), basename( __FILE__ ) ) );

		// Load classes.
		$this->classes();

		// Hooks to run on plugin init.
		$this->init_hooks();

		do_action( 'ejcc_loaded' );
	}

	/**
	 * Hooks into various necessary hooks
	 * at the init time.
	 *
	 * @return void
	 */
	public function init_hooks() {
		do_action( 'before_ejcc_init' );

		// Add Scripts.
		add_action( 'wp_enqueue_scripts', [ $this, 'scripts' ] );

		// Add Styles.
		add_action( 'wp_enqueue_scripts', [ $this, 'styles' ] );

		// Boot other classes.
		EJCC_Settings::hooks();

		do_action( 'ejcc_init' );
	}

	/**
	 * Load Classes
	 */
	public function classes() {
		require_once 'classes/class-consent.php';
		require_once 'classes/class-trackers.php';
		require_once 'classes/class-epicjungle-consent-cookie-settings.php';
	}

	/**
	 * Load necessary scripts for the plugin.
	 */
	public function scripts() {

		/**
		 * If the banner shouldn't load on this page, bail early.
		 */
		if ( ! self::should_load_banner() ) {
			return;
		}

		wp_register_script( 'epicjungle-cookie-consent', EPICJUNGLE_EXTENSIONS_URL . 'assets/js/cookie-banner.js', [ 'ejcc-vendor' ]);

		wp_register_script( 'ejcc-vendor', EPICJUNGLE_EXTENSIONS_URL . 'assets/js/cookie-banner-vendor.js', [] );

		/**
		 * We localize the script to add our texts.
		 * These are changeable by filters. See the functions
		 * that get the texts below.
		 */
		wp_localize_script( 'epicjungle-cookie-consent', 'ejcc', [
			'cookieConsentTitle'            => EJCC_Settings::get_consent_title(),
			'cookieConsentText'             => EJCC_Settings::get_consent_text(),
			'acceptText'                    => EJCC_Settings::get_accept_text(),
			'style'                         => EJCC_Settings::get_style(),
			'configureSettingsText'         => EJCC_Settings::get_configure_settings_text(),
			'necessaryText'                 => EJCC_Settings::get_only_necessary_text(),
			'rememberDuration'              => self::get_remember_me_duration(),
			'preferencesCookieName'         => self::get_preferences_cookie_name(),
			'consentedCategoriesCookieName' => self::get_categories_cookie_name(),
			'necessaryHeading'              => EJCC_Settings::get_settings_necessary_heading(),
			'necessaryDescription'          => EJCC_Settings::get_settings_necessary_description(),
			'isAnalyticsShown'              => EJCC_Settings::is_analytics_shown() ? '1' : '0',
			'analyticsHeading'              => EJCC_Settings::get_settings_analytics_heading(),
			'analyticsDescription'          => EJCC_Settings::get_settings_analytics_description(),
			'isMarketingShown'              => EJCC_Settings::is_marketing_shown() ? '1' : '0',
			'marketingHeading'              => EJCC_Settings::get_settings_marketing_heading(),
			'marketingDescription'          => EJCC_Settings::get_settings_marketing_description(),
			'saveSettingsText'              => EJCC_Settings::get_save_settings_button_title(),
			'settingsTitle'                 => EJCC_Settings::get_settings_title(),
			'settingsDescription'           => EJCC_Settings::get_settings_description(),
			'debug'                         => $this->is_debugging(),
		] );

		/**
		 * Add the whitelist and blacklist.
		 */
		wp_add_inline_script( 'ejcc-vendor', $this->get_allow_and_disallowlists(), 'before' );

		// Finally, enqueue!
		wp_enqueue_script( 'ejcc-vendor' );
		wp_enqueue_script( 'epicjungle-cookie-consent' );
	}

	/**
	 * Get the black- and whitelist HTML.
	 *
	 * @return string
	 */
	public function get_allow_and_disallowlists() {
		$output = "window.YETT_BLACKLIST = [" . esc_js( EJCC_Trackers::get_disallow_for_js() ) . "];\n";

		if ( ! empty( EJCC_Trackers::get_allowlist_for_js() ) ) {
			$output .= 'window.YETT_WHITELIST = [' . esc_js( EJCC_Trackers::get_allowlist_for_js() ) . '];';
		}

		return $output;
	}

	/**
	 * Load the built-in styles for the plugin.
	 */
	public function styles() {
		/**
		 * If the banner shouldn't load on this page, bail early.
		 */
		if ( ! self::should_load_banner() ) {
			return;
		}

		/**
		 * Don't load anything if we are asked not
		 * to load the stylesheet.
		 */
		if ( false === apply_filters( 'ejcc_load_stylesheet', true ) || true === EJCC_DEV_MODE ) {
			return;
		}

		/**
		 * Register the main stylesheet.
		 */
		wp_register_style( 'epicjungle-cookie-consent', EPICJUNGLE_EXTENSIONS_URL . 'assets/css/cookie-banner.css' );

		// Finally, enqueue!
		wp_enqueue_style( 'epicjungle-cookie-consent' );
	}

	/**
	 * Check if we should  be loading the banner on this page.
	 * This hook allows overriding to hide the banner on certain pages or templates.
	 *
	 * @return bool
	 */
	public static function should_load_banner() {
		return apply_filters( 'ejcc_is_active_on_page', true );
	}

	/**
	 * Get the name of the cookie.
	 *
	 * @return string
	 */
	public static function get_preferences_cookie_name() {
		return apply_filters( 'ejcc_preferences_cookie_name', 'ejcc_has_preferences' );
	}

	/**
	 * Get Categories Cookie Name
	 *
	 * @return string
	 */
	public static function get_categories_cookie_name() {
		return apply_filters( 'ejcc_categories_cookie_name', 'ejcc_consent_categories' );
	}

	/**
	 * Get how many days the user should be remembered.
	 *
	 * @return int
	 */
	public static function get_remember_me_duration() {
		return apply_filters( 'ejcc_remember_duration', 90 );
	}

	/**
	 * Check if we are debugging or not.
	 *
	 * @return bool
	 */
	public function is_debugging() {
		if ( defined( 'EJCC_DEBUG' ) ) {
			return EJCC_DEBUG;
		}

		return false;
	}

}

/**
 * Returns an instance of the plugin class.
 *
 * @return EpicJungle_Cookie_Consent
 */
function epicjungle_cookie_consent() {
	return EpicJungle_Cookie_Consent::instance();
}

// Initialize the class instance only once
epicjungle_cookie_consent();
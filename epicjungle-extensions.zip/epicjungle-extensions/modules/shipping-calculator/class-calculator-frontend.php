<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class calculatorShippingFrontend {

	public function __construct() {
		add_action( 'wp_head', array( $this, 'get_admin_ajax' ) );
		add_action( 'wp_enqueue_scripts', array( $this,'register_scripts') );
		add_action( ( 'woocommerce_product_meta_end' ), array( $this, 'epicjungle_form_shipping_calc' ), 10);
	}

	public function epicjungle_form_shipping_calc() {
    $wscp_nonce = wp_create_nonce( 'wscp-nonce' );
	$text_button_shipping_calc = esc_html__( 'Calcular', 'epicjungle-extensions' );
	
		echo '<div id="shipping-calc">
		<label>Consultar prazo e valor da entrega</label>
		
		<div class="input-group form-group">
		  <input class="form-control" id="wscp-postcode" type="tel" placeholder="Informe seu CEP" name="wscp-postcode">
		  <button class="btn btn-primary btn-input-group-right" id="wscp-button" type="button">
			<span id="span-shipping-calc" class="text-buy-now">'.$text_button_shipping_calc.'</span>
			<span id="preloader-shipping-calc" class="spinner-border spinner-border-md d-none"></span>
		  </button>
		</div>
		
		<a class="cs-fancy-link form-text postcode" href="https://buscacepinter.correios.com.br/app/endereco/" target="_blank">Não sei meu CEP</a>
		
		    <input type="hidden" name="wscp-nonce" id="wscp-nonce" value="'.$wscp_nonce.'"/>
			<input type="hidden" name="add-to-cart" value="<?= get_the_ID() ?>">
			<div id="wscp-response"></div>
		</div>';
    
	}

	public function register_scripts() {
		wp_register_script( 'shipping-calc', EPICJUNGLE_EXTENSIONS_URL . '/assets/js/shipping-calc.js' );
	    wp_enqueue_script('shipping-calc');
	}

	public function get_admin_ajax() {
		echo "<script> var wscp_admin_url = '".admin_url( 'admin-ajax.php' )."'; </script>";
	}
	
}

new calculatorShippingFrontend();
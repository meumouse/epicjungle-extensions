<?php
/**
 * EpicJungle Admin
 *
 * @class    EpicJungle_Extensions_Admin
 * @author   MeuMouse.com
 * @category Admin
 * @package  EpicJungleExtensions/Admin
 * @version  1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * EpicJungle_Extensions_Admin class.
 */
class EpicJungle_Extensions_Admin {

    /**
     * Constructor.
     */
    public function __construct() {
        add_action( 'init', array( $this, 'includes' ) );
        add_action( 'admin_init', array( $this, 'buffer' ), 1 );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_styles' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

    }

    /**
     * Output buffering allows admin screens to make redirects later on.
     */
    public function buffer() {
        ob_start();
    }

    /**
     * Include any classes we need within admin.
     */
    public function includes() {
        include_once dirname( __FILE__ ) . '/epicjungle-meta-box-functions.php';
        include_once dirname( __FILE__ ) . '/class-epicjungle-admin-meta-boxes.php';
    }

    /**
     * Enqueue style.
     */
    public function admin_styles() {
        $version = EpicJungle_Extensions()->version;
        wp_register_style( 'epicjungle-admin-meta-boxes', plugins_url( '/assets/css/admin-meta-boxes.css', EPICJUNGLE_PLUGIN_FILE ), array(), $version );
        wp_enqueue_style( 'epicjungle-admin-meta-boxes' );

    }

    /**
     * Enqueue scripts.
     */
    public function admin_scripts() {
        $version = EpicJungle_Extensions()->version;
        wp_register_script( 'epicjungle-admin-meta-boxes', plugins_url( '/assets/js/admin-meta-boxes.js', EPICJUNGLE_PLUGIN_FILE ), array( 'jquery', 'jquery-ui-datepicker', 'jquery-ui-sortable'), $version );
        wp_enqueue_script( 'epicjungle-admin-meta-boxes' );
    }

    /**
     * Include admin files conditionally.
     */
    public function conditional_includes() {
        if ( ! $screen = get_current_screen() ) {
            return;
        }
    }
}

return new EpicJungle_Extensions_Admin();
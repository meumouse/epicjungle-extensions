<?php
/**
 * Docs Icons
 *
 * Display the docs meta box.
 *
 * @author      MeuMouse.com
 * @category    Admin
 * @package     EpicJungle/Admin/Meta Boxes
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * EpicJungle_Meta_Box_Docs Class.
 */
class EpicJungle_Meta_Box_Docs {

    /**
     * Output the metabox.
     *
     * @param WP_Post $post
     */
    public static function output( $post ) {
        global $thepostid;
        $thepostid      = $post->ID;

        wp_nonce_field( 'epicjungle_save_data', 'epicjungle_meta_nonce' );

        self::output_docs( $post );
    }

    private static function output_docs( $post ) {

        if ( ! function_exists( 'epicjungle_get_docs_meta' ) ) {
            return;
        }

        $wedocs = epicjungle_get_docs_meta();

        ?><div class="epicjungle-options"><?php

            epicjungle_wp_text_input( array(
                'id'            => '_wedocs_post_featured_icon',
                'name'          => '_wedocs[post_featured_icon]',
                'label'         => esc_html__( 'Featured Icon', 'epicjungle-extensions' ),
                'value'         => isset( $wedocs['post_featured_icon'] ) ? $wedocs['post_featured_icon'] : '',
            ) );

            epicjungle_wp_select( array(
                'label'         => esc_html__( 'Featured Icon Background', 'epicjungle-extensions' ),
                'name'          => '_wedocs[post_featured_icon_bg]',
                'id'            => '_wedocs_post_featured_icon_bg',
                'type'          => 'select',
                'options'       => array(
                    'primary'       => esc_html__( 'Primary', 'epicjungle-extensions'),
                    'secondary'     => esc_html__( 'Secondary', 'epicjungle-extensions'), 
                    'success'       => esc_html__( 'Success', 'epicjungle-extensions'),
                    'danger'        => esc_html__( 'Danger', 'epicjungle-extensions'),
                    'warning'       => esc_html__( 'Warning', 'epicjungle-extensions'),
                    'info'          => esc_html__( 'Info', 'epicjungle-extensions'),
                    'light'         => esc_html__( 'Light', 'epicjungle-extensions'),
                    'dark'          => esc_html__( 'Dark', 'epicjungle-extensions'),
                    'primary-desat' => esc_html__( 'Primary Desat', 'epicjungle-extensions'),
                ),
                'value'         => isset( $wedocs['post_featured_icon_bg'] ) ? $wedocs['post_featured_icon_bg'] : '',
            ) );

        ?></div><?php
    }
    

    /**
     * Save meta box data.
     *
     * @param int     $post_id
     * @param WP_Post $post
     */


    public static function save( $post_id, $post ) {
        if ( isset( $_POST['_wedocs'] ) ) {
            $clean_docs_options = epicjungle_clean( $_POST['_wedocs'] );
            update_post_meta( $post_id, '_docs_options',  serialize( $clean_docs_options ) );
        }   
    }
}

<?php
/**
 *
 * Display the page meta box.
 *
 * @author      MeuMouse.com
 * @category    Admin
 * @package     epicjungle/Admin/MetaBoxes
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists( 'EpicJungle_Meta_Box_Cover_Image' ) ) {
    /**
     * EpicJungle_Meta_Box_Cover_Image Class.
     */
    class EpicJungle_Meta_Box_Cover_Image {
        /**
         * Render Meta Box content.
         *
         * @param WP_Post $post The post object.
         */
        public static function output( $post ) {

            $clean_meta_data = get_post_meta( $post->ID, '_ej_cover_image', true );
            $ej_cover_image  = maybe_unserialize( $clean_meta_data );

            wp_nonce_field( 'epicjungle_save_data', 'epicjungle_meta_nonce' );

            ?><div class="epicjungle-options"><?php

                epicjungle_wp_upload_image( array(
                    'id'            => '_ej_cover_image',
                    'name'          => '_ej_cover_image',
                    'label'         => esc_html__( 'Cover Image', 'epicjungle-extensions' ),
                    'placeholder'   => true,
                    'value'         => isset( $ej_cover_image ) ? $ej_cover_image : '',

                ) );

            ?></div><?php
        }

        public static function save( $post_id, $post ) {
            if ( isset( $_POST['_ej_cover_image'] ) ) {
                $clean_ej_cover_image = epicjungle_clean( $_POST['_ej_cover_image'] );
                update_post_meta( $post_id, '_ej_cover_image',  serialize( $clean_ej_cover_image ) );
            }   
        }
    }
}

<?php
/**
 *
 * Display the page meta box.
 *
 * @author      MadrasThemes
 * @category    Admin
 * @package     EpicJungle/Admin/MetaBoxes
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists( 'EpicJungle_Meta_Box_Page' ) ) {
    /**
     * EpicJungle_Meta_Box_Page Class.
     */
    class EpicJungle_Meta_Box_Page {
        /**
         * Render Meta Box content.
         *
         * @param WP_Post $post The post object.
         */
        public static function output( $post ) {

            $clean_meta_data = get_post_meta( $post->ID, '_ej_page_options', true );
            $ej_page_options = maybe_unserialize( $clean_meta_data );

            $static_contents = function_exists( 'epicjungle_static_content_options' ) ? epicjungle_static_content_options() : [];

            if( ! is_array( $ej_page_options ) ) {
                $ej_page_options  = array();
            }

            wp_nonce_field( 'epicjungle_save_data', 'epicjungle_meta_nonce' );

            ?><div class="epicjungle-options">
                <div class="options_group">

                    <h3 class="option-group-title general-options"><?php echo esc_html__( 'General', 'epicjungle-extensions' ) ?></h3>

                    <?php
                    epicjungle_wp_text_input( array(
                        'id'            => 'ej_page_options_general_body_classes',
                        'name'          => 'ej_page_options[general][body_classes]',
                        'label'         => esc_html__( 'Additional Body Classes', 'epicjungle-extensions' ),
                        'value'         => ( isset( $ej_page_options['general'] ) && isset( $ej_page_options['general']['body_classes'] ) ) ? $ej_page_options['general']['body_classes'] : '',
                    ) );

                    ?>
                </div>
                <div class="options_group">

                    <h3 class="option-group-title header-options"><?php echo esc_html__( 'Header', 'epicjungle-extensions' ) ?></h3>

                    <?php

                    epicjungle_wp_checkbox( array(
                        'id'            => 'ej_page_options_header_enable_custom_header',
                        'name'          => 'ej_page_options[header][enable_custom_header]',
                        'label'         => esc_html__( 'Enable Custom Header', 'epicjungle-extensions' ),
                        'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_custom_header'] ) ) ? $ej_page_options['header']['enable_custom_header'] : '',
                        'class'         => 'show_hide_checkbox',
                    ) );

                    ?><div class="show_if_ej_page_options_header_enable_custom_header_yes hide_if_ej_page_options_header_enable_custom_header"><?php

                        epicjungle_wp_select( array(
                            'id'            => 'ej_page_options_header_navbar_variant',
                            'name'          => 'ej_page_options[header][navbar_variant]',
                            'type'          => 'select',
                            'label'         => esc_html__( 'Navbar Variant', 'epicjungle-extensions' ),
                            'options'       => array(
                                'solid'      => esc_html__( 'Solid', 'epicjungle-extensions' ),
                                'dashboard'  => esc_html__( 'Dashboard', 'epicjungle-extensions' ),
                                'shop'       => esc_html__( 'Shop', 'epicjungle-extensions' ),
                                'button'     => esc_html__( 'Simple', 'epicjungle-extensions' ),
                                'social'     => esc_html__( 'Social', 'epicjungle-extensions' ),
                            ),
                            'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['navbar_variant'] ) ) ? $ej_page_options['header']['navbar_variant'] : 'solid',
                            'class'         => 'show_hide_select',
                        ) );

                        

                        ?><div class="show_if_ej_page_options_header_navbar_variant_shop hide_if_ej_page_options_header_navbar_variant"><?php

                            epicjungle_wp_checkbox( array(
                                'id'            => 'ej_page_options_header_enable_topbar',
                                'name'          => 'ej_page_options[header][enable_topbar]',
                                'label'         => esc_html__( 'Enable Topbar', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_topbar'] ) ) ? $ej_page_options['header']['enable_topbar'] : '',
                                'class'         => 'show_hide_checkbox',
                            ) );

                            epicjungle_wp_select( array(
                                'id'            => 'ej_page_options_header_topbar_skin',
                                'name'          => 'ej_page_options[header][topbar_skin]',
                                'type'          => 'select',
                                'label'         => esc_html__( 'Topbar Skin', 'epicjungle-extensions' ),
                                'options'       => array(
                                    'light'     => esc_html__( 'Light', 'epicjungle-extensions'),
                                    'dark'      => esc_html__( 'Dark', 'epicjungle-extensions'),
                                ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['topbar_skin'] ) ) ? $ej_page_options['header']['topbar_skin'] : 'dark',
                                'wrapper_class' => 'show_if_ej_page_options_header_enable_topbar_yes hide_if_ej_page_options_header_enable_topbar',
                            ) );

                        ?></div><?php

                        ?><div class="show_if_ej_page_options_header_navbar_variant_solid show_if_ej_page_options_header_navbar_variant_button hide_if_ej_page_options_header_navbar_variant"><?php

                            epicjungle_wp_checkbox( array(
                                'id'            => 'ej_page_options_header_enable_transparent',
                                'name'          => 'ej_page_options[header][enable_transparent]',
                                'label'         => esc_html__( 'Enable Transparent', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_transparent'] ) ) ? $ej_page_options['header']['enable_transparent'] : '',
                                'class'         => 'show_hide_checkbox',
                            ) );

                             epicjungle_wp_checkbox( array(
                                'id'            => 'ej_page_options_header_enable_transparent_logo',
                                'name'          => 'ej_page_options[header][enable_transparent_logo]',
                                'label'         => esc_html__( 'Enable Transparent Logo', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_transparent_logo'] ) ) ? $ej_page_options['header']['enable_transparent_logo'] : '',
                                'class'         => 'show_hide_checkbox',
                                'wrapper_class' => 'show_if_ej_page_options_header_enable_transparent_yes hide_if_ej_page_options_header_enable_transparent',
                            ) );


                            epicjungle_wp_select( array(
                                'id'            => 'ej_page_options_header_transparent_text_color',
                                'name'          => 'ej_page_options[header][transparent_text_color]',
                                'type'          => 'select',
                                'label'         => esc_html__( 'Text Color (Transparent BG)', 'epicjungle-extensions' ),
                                'options'       => array(
                                    'light'        => esc_html__( 'Light', 'epicjungle-extensions' ),
                                    'dark'         => esc_html__( 'Dark', 'epicjungle-extensions' ),
                                ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['transparent_text_color'] ) ) ? $ej_page_options['header']['transparent_text_color'] : 'dark',
                                'class'         => 'show_hide_select',
                                'wrapper_class' => 'show_if_ej_page_options_header_enable_transparent_yes hide_if_ej_page_options_header_enable_transparent',
                            ) );

                        ?></div><?php

                        ?><div class="show_if_ej_page_options_header_navbar_variant_shop show_if_ej_page_options_header_navbar_variant_solid show_if_ej_page_options_header_navbar_variant_social hide_if_ej_page_options_header_navbar_variant"><div class="show_if_ej_page_options_header_enable_transparent_no hide_if_ej_page_options_header_enable_transparent"><?php

                            epicjungle_wp_select( array(
                                'id'            => 'ej_page_options_header_navbar_skin',
                                'name'          => 'ej_page_options[header][navbar_skin]',
                                'type'          => 'select',
                                'label'         => esc_html__( 'Navbar Skin', 'epicjungle-extensions' ),
                                'options'       => array(
                                    'dark'         => esc_html__( 'Dark', 'epicjungle-extensions' ),
                                    'primary'      => esc_html__( 'Primary', 'epicjungle-extensions' ),
                                    'secondary'    => esc_html__( 'Gray', 'epicjungle-extensions' ),
                                    'light'        => esc_html__( 'Light', 'epicjungle-extensions' ),
                                ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['navbar_skin'] ) ) ? $ej_page_options['header']['navbar_skin'] : 'light',
                            ) );

                            epicjungle_wp_checkbox( array(
                                'id'            => 'ej_page_options_header_enable_boxshadow',
                                'name'          => 'ej_page_options[header][enable_boxshadow]',
                                'label'         => esc_html__( 'Enable Box Shadow', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_boxshadow'] ) ) ? $ej_page_options['header']['enable_boxshadow'] : '',
                            ) );

                        ?></div></div><?php



                        ?><div class="show_if_ej_page_options_header_navbar_variant_button  hide_if_ej_page_options_header_navbar_variant"><div class="show_if_ej_page_options_header_enable_transparent_no hide_if_ej_page_options_header_enable_transparent"><?php

                            epicjungle_wp_checkbox( array(
                                'id'            => 'ej_page_options_header_enable_button_variant_boxshadow',
                                'name'          => 'ej_page_options[header][enable_button_variant_boxshadow]',
                                'label'         => esc_html__( 'Enable Box Shadow', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_button_variant_boxshadow'] ) ) ? $ej_page_options['header']['enable_button_variant_boxshadow'] : '',
                            ) );

                        ?></div></div><?php

                        // epicjungle_wp_checkbox( array(
                        //     'id'            => 'ej_page_options_header_enable_slanted_bg',
                        //     'name'          => 'ej_page_options[header][enable_slanted_bg]',
                        //     'label'         => esc_html__( 'Enable Slanted Background', 'epicjungle-extensions' ),
                        //     'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_slanted_bg'] ) ) ? $ej_page_options['header']['enable_slanted_bg'] : '',
                        //     'wrapper_class' => 'show_if_ej_page_options_header_navbar_variant_dashboard hide_if_ej_page_options_header_navbar_variant',
                        // ) );

                        epicjungle_wp_checkbox( array(
                            'id'            => 'ej_page_options_header_enable_sticky',
                            'name'          => 'ej_page_options[header][enable_sticky]',
                            'label'         => esc_html__( 'Enable Sticky', 'epicjungle-extensions' ),
                            'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_sticky'] ) ) ? $ej_page_options['header']['enable_sticky'] : '',
                        ) );

                        epicjungle_wp_checkbox( array(
                            'id'            => 'ej_page_options_header_enable_search',
                            'name'          => 'ej_page_options[header][enable_search]',
                            'label'         => esc_html__( 'Enable Search', 'epicjungle-extensions' ),
                            'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_search'] ) ) ? $ej_page_options['header']['enable_search'] : '',
                            'wrapper_class' => 'show_if_ej_page_options_header_navbar_variant_shop show_if_ej_page_options_header_navbar_variant_social hide_if_ej_page_options_header_navbar_variant',
                        ) );


                        epicjungle_wp_checkbox( array(
                            'id'            => 'ej_page_options_header_enable_header_social_menu',
                            'name'          => 'ej_page_options[header][enable_header_social_menu]',
                            'label'         => esc_html__( 'Enable Social Links', 'epicjungle-extensions' ),
                            'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_header_social_menu'] ) ) ? $ej_page_options['header']['enable_header_social_menu'] : '',
                            'wrapper_class' => 'show_if_ej_page_options_header_navbar_variant_social  hide_if_ej_page_options_header_navbar_variant',
                        ) );


                        if( function_exists( 'epicjungle_is_woocommerce_activated' ) && epicjungle_is_woocommerce_activated() ) {
                            epicjungle_wp_checkbox( array(
                                'id'            => 'ej_page_options_header_enable_account',
                                'name'          => 'ej_page_options[header][enable_account]',
                                'label'         => esc_html__( 'Enable Account', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_account'] ) ) ? $ej_page_options['header']['enable_account'] : '',
                                'wrapper_class' => 'show_if_ej_page_options_header_navbar_variant_shop show_if_ej_page_options_header_navbar_variant_solid show_if_ej_page_options_header_navbar_variant_dashboard hide_if_ej_page_options_header_navbar_variant',
                            ) );

                            epicjungle_wp_checkbox( array(
                                'id'            => 'ej_page_options_header_enable_cart',
                                'name'          => 'ej_page_options[header][enable_cart]',
                                'label'         => esc_html__( 'Enable Cart', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_cart'] ) ) ? $ej_page_options['header']['enable_cart'] : '',
                                'wrapper_class' => 'show_if_ej_page_options_header_navbar_variant_shop hide_if_ej_page_options_header_navbar_variant',
                            ) );
                        }

                        ?><div class="show_if_ej_page_options_header_navbar_variant_button hide_if_ej_page_options_header_navbar_variant">
                            <?php

                            epicjungle_wp_checkbox( array(
                                'id'            => 'ej_page_options_header_enable_action_button',
                                'name'          => 'ej_page_options[header][enable_action_button]',
                                'label'         => esc_html__( 'Enable Button', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['enable_action_button'] ) ) ? $ej_page_options['header']['enable_action_button'] : '',
                                'class'         => 'show_hide_checkbox',
                            ) );

                            // epicjungle_wp_text_input( array(
                            //     'id'            => 'ej_page_options_header_action_button_link',
                            //     'name'          => 'ej_page_options[header][action_button_link]',
                            //     'label'         => esc_html__( 'Button Link', 'epicjungle-extensions' ),
                            //     'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['action_button_link'] ) ) ? $ej_page_options['header']['action_button_link'] : '#',
                            //     'wrapper_class' => 'show_if_ej_page_options_header_enable_action_button_yes hide_if_ej_page_options_header_enable_action_button',
                            // ) );

                            // epicjungle_wp_text_input( array(
                            //     'id'            => 'ej_page_options_header_action_button_text',
                            //     'name'          => 'ej_page_options[header][action_button_text]',
                            //     'label'         => esc_html__( 'Button Text', 'epicjungle-extensions' ),
                            //     'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['action_button_text'] ) ) ? $ej_page_options['header']['action_button_text'] : esc_html__( 'Buy now', 'epicjungle-extensions' ),
                            //     'wrapper_class' => 'show_if_ej_page_options_header_enable_action_button_yes hide_if_ej_page_options_header_enable_action_button',
                            // ) );

                            // epicjungle_wp_select( array(
                            //     'id'            => 'ej_page_options_header_action_button_size',
                            //     'name'          => 'ej_page_options[header][action_button_size]',
                            //     'type'          => 'select',
                            //     'label'         => esc_html__( 'Button Size', 'epicjungle-extensions' ),
                            //     'options'       => array(
                            //         ''          => esc_html__( 'Default', 'epicjungle-extensions'),
                            //         'btn-xs'    => esc_html__( 'Extra Small', 'epicjungle-extensions'),
                            //         'btn-sm'    => esc_html__( 'Small', 'epicjungle-extensions'),
                            //         'btn-lg'    => esc_html__( 'Large', 'epicjungle-extensions'),
                            //     ),
                            //     'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['action_button_size'] ) ) ? $ej_page_options['header']['action_button_size'] : 'btn-sm',
                            //     'wrapper_class' => 'show_if_ej_page_options_header_enable_action_button_yes hide_if_ej_page_options_header_enable_action_button',
                            // ) );

                            // epicjungle_wp_text_input( array(
                            //     'id'            => 'ej_page_options_header_action_button_background',
                            //     'name'          => 'ej_page_options[header][action_button_background]',
                            //     'label'         => esc_html__( 'Button Background', 'epicjungle-extensions' ),
                            //     'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['action_button_background'] ) ) ? $ej_page_options['header']['action_button_background'] : '#335eea',
                            //     'wrapper_class' => 'show_if_ej_page_options_header_enable_action_button_yes hide_if_ej_page_options_header_enable_action_button',
                            // ) );

                            // epicjungle_wp_text_input( array(
                            //     'id'            => 'ej_page_options_header_action_button_text_color',
                            //     'name'          => 'ej_page_options[header][action_button_text_color]',
                            //     'label'         => esc_html__( 'Button Text Color', 'epicjungle-extensions' ),
                            //     'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['action_button_text_color'] ) ) ? $ej_page_options['header']['action_button_text_color'] : '#FFFFFF',
                            //     'wrapper_class' => 'show_if_ej_page_options_header_enable_action_button_yes hide_if_ej_page_options_header_enable_action_button',
                            // ) );

                            // epicjungle_wp_text_input( array(
                            //     'id'            => 'ej_page_options_header_action_button_background_hover',
                            //     'name'          => 'ej_page_options[header][action_button_background_hover]',
                            //     'label'         => esc_html__( 'Button Background Hover', 'epicjungle-extensions' ),
                            //     'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['action_button_background_hover'] ) ) ? $ej_page_options['header']['action_button_background_hover'] : '#1746e0',
                            //     'wrapper_class' => 'show_if_ej_page_options_header_enable_action_button_yes hide_if_ej_page_options_header_enable_action_button',
                            // ) );

                            // epicjungle_wp_text_input( array(
                            //     'id'            => 'ej_page_options_header_action_button_text_color_hover',
                            //     'name'          => 'ej_page_options[header][action_button_text_color_hover]',
                            //     'label'         => esc_html__( 'Button Text Color Hover', 'epicjungle-extensions' ),
                            //     'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['action_button_text_color_hover'] ) ) ? $ej_page_options['header']['action_button_text_color_hover'] : '#FFFFFF',
                            //     'wrapper_class' => 'show_if_ej_page_options_header_enable_action_button_yes hide_if_ej_page_options_header_enable_action_button',
                            // ) );

                            // epicjungle_wp_select( array(
                            //     'id'            => 'ej_page_options_header_action_button_background',
                            //     'name'          => 'ej_page_options[header][action_button_background]',
                            //     'type'          => 'select',
                            //     'label'         => esc_html__( 'Button Background', 'epicjungle-extensions' ),
                            //     'options'       => array(
                            //         'btn-primary'           => esc_html__( 'Primary', 'epicjungle-extensions'),
                            //         'btn-secondary'         => esc_html__( 'Secondary', 'epicjungle-extensions'),
                            //         'btn-success'           => esc_html__( 'Success', 'epicjungle-extensions'),
                            //         'btn-danger'            => esc_html__( 'Danger', 'epicjungle-extensions'),
                            //         'btn-warning'           => esc_html__( 'Warning', 'epicjungle-extensions'),
                            //         'btn-info'              => esc_html__( 'Info', 'epicjungle-extensions'),
                            //         'btn-light'             => esc_html__( 'Light', 'epicjungle-extensions'),
                            //         'btn-dark'              => esc_html__( 'Dark', 'epicjungle-extensions'),
                            //         'btn-link'              => esc_html__( 'Link', 'epicjungle-extensions'),
                            //         'btn-outline-primary'   => esc_html__( 'Outline Primary', 'epicjungle-extensions'),
                            //         'btn-outline-secondary' => esc_html__( 'Outline Secondary', 'epicjungle-extensions'),
                            //         'btn-outline-success'   => esc_html__( 'Outline Success', 'epicjungle-extensions'),
                            //         'btn-outline-danger'    => esc_html__( 'Outline Danger', 'epicjungle-extensions'),
                            //         'btn-outline-warning'   => esc_html__( 'Outline Warning', 'epicjungle-extensions'),
                            //         'btn-outline-info'      => esc_html__( 'Outline Info', 'epicjungle-extensions'),
                            //         'btn-outline-light'     => esc_html__( 'Outline Light', 'epicjungle-extensions'),
                            //         'btn-outline-dark'      => esc_html__( 'Outline Dark', 'epicjungle-extensions'),
                            //         'btn-primary-soft'      => esc_html__( 'Primary Soft', 'epicjungle-extensions'),
                            //         'btn-secondary-soft'    => esc_html__( 'Secondary Soft', 'epicjungle-extensions'),
                            //         'btn-success-soft'      => esc_html__( 'Success Soft', 'epicjungle-extensions'),
                            //         'btn-danger-soft'       => esc_html__( 'Danger Soft', 'epicjungle-extensions'),
                            //         'btn-warning-soft'      => esc_html__( 'Warning Soft', 'epicjungle-extensions'),
                            //         'btn-info-soft'         => esc_html__( 'Info Soft', 'epicjungle-extensions'),
                            //     ),
                            //     'value'         => ( isset( $ej_page_options['header'] ) && isset( $ej_page_options['header']['action_button_background'] ) ) ? $ej_page_options['header']['action_button_background'] : 'btn-primary',
                            //     'wrapper_class' => 'show_if_ej_page_options_header_enable_action_button_yes hide_if_ej_page_options_header_enable_action_button',
                            // ) );

                            ?>
                        </div>

                    </div>

                </div>
                <div class="options_group">
                    <h3 class="option-group-title footer-options"><?php echo esc_html__( 'Footer', 'epicjungle-extensions' ) ?></h3>

                    <?php

                    epicjungle_wp_checkbox( array(
                        'id'            => 'ej_page_options_footer_enable_custom_footer',
                        'name'          => 'ej_page_options[footer][enable_custom_footer]',
                        'label'         => esc_html__( 'Enable Custom Footer', 'epicjungle-extensions' ),
                        'value'         => ( isset( $ej_page_options['footer'] ) && isset( $ej_page_options['footer']['enable_custom_footer'] ) ) ? $ej_page_options['footer']['enable_custom_footer'] : '',
                        'class'         => 'show_hide_checkbox',
                    ) );

                    ?>

                    <div class="options_group show_if_ej_page_options_footer_enable_custom_footer_yes hide_if_ej_page_options_footer_enable_custom_footer">

                        <?php

                        epicjungle_wp_select( array(
                            'id'            => 'ej_page_options_footer_footer_variant',
                            'name'          => 'ej_page_options[footer][footer_variant]',
                            'type'          => 'select',
                            'label'         => esc_html__( 'Footer Variant', 'epicjungle-extensions' ),
                            'options'       => array(
                                'default'      => esc_html__( 'Default', 'epicjungle-extensions' ),
                                'simple'       => esc_html__( 'Footer Simple', 'epicjungle-extensions' ),
                                'simple-2'     => esc_html__( 'Footer Social Icons', 'epicjungle-extensions' ),
                                'shop'         => esc_html__( 'Footer Shop', 'epicjungle-extensions' ),
                                'blog'         => esc_html__( 'Footer Blog', 'epicjungle-extensions' ),
                                'v6'           => esc_html__( 'Footer v6', 'epicjungle-extensions' ),
                                'v7'           => esc_html__( 'Footer v7', 'epicjungle-extensions' ),
                                'v8'           => esc_html__( 'Footer v8', 'epicjungle-extensions' ),
                                'v9'           => esc_html__( 'Footer v9', 'epicjungle-extensions' ),
                            ),
                            'value'         => isset( $ej_page_options['footer']['footer_variant'] ) ? $ej_page_options['footer']['footer_variant'] : 'default',
                            'class'         => 'show_hide_select',
                        ) );

                        epicjungle_wp_select( array(
                            'id'            => 'ej_page_options_footer_footer_skin',
                            'name'          => 'ej_page_options[footer][footer_skin]',
                            'type'          => 'select',
                            'label'         => esc_html__( 'Footer Skin', 'epicjungle-extensions' ),
                            'options'       => array(
                                'dark'      => esc_html__( 'Dark', 'epicjungle-extensions' ),
                                'light'     => esc_html__( 'Light', 'epicjungle-extensions' ),
                            ),
                            'value'         => isset( $ej_page_options['footer']['footer_skin'] ) ? $ej_page_options['footer']['footer_skin'] : 'dark',
                            'wrapper_class' => 'hide_if_ej_page_options_footer_footer_variant show_if_ej_page_options_footer_footer_variant_default show_if_ej_page_options_footer_footer_variant_simple show_if_ej_page_options_footer_footer_variant_v7 show_if_ej_page_options_footer_footer_variant_v8 show_if_ej_page_options_footer_footer_variant_v9',
                        ) );

                        epicjungle_wp_text_input( array(
                            'id'            => 'ej_page_options_footer_contact_title',
                            'name'          => 'ej_page_options[footer][contact_title]',
                            'label'         => esc_html__( 'Contact Title', 'epicjungle-extensions' ),
                            'value'         => ( isset( $ej_page_options['footer'] ) && isset( $ej_page_options['footer']['contact_title'] ) ) ? $ej_page_options['footer']['contact_title'] : esc_html__( 'Contacts', 'epicjungle-extensions' ),
                            'wrapper_class' => 'hide_if_ej_page_options_footer_footer_variant show_if_ej_page_options_footer_footer_variant_v7',
                        ) );

                        epicjungle_wp_textarea_input( array(
                            'id'            => 'ej_page_options_footer_copyright',
                            'name'          => 'ej_page_options[footer][copyright]',
                            'label'         => esc_html__( 'Copyright', 'epicjungle-extensions' ),
                            'value'         => ( isset( $ej_page_options['footer'] ) && isset( $ej_page_options['footer']['copyright'] ) ) ? $ej_page_options['footer']['copyright'] : '',
                        ) );

                        if ( function_exists( 'epicjungle_is_mas_static_content_activated' ) && epicjungle_is_mas_static_content_activated() ) {

                            epicjungle_wp_select( array(
                                'id'            => 'ej_page_options_footer_footer_static_widgets',
                                'name'          => 'ej_page_options[footer][footer_static_widgets]',
                                'type'          => 'select',
                                'label'         => esc_html__( 'Footer Static Widgets', 'epicjungle-extensions' ),
                                'options'       => $static_contents,
                                'value'         => isset( $ej_page_options['footer']['footer_static_widgets'] ) ? $ej_page_options['footer']['footer_static_widgets'] : '',
                                'wrapper_class' => 'hide_if_ej_page_options_footer_footer_variant show_if_ej_page_options_footer_footer_variant_default show_if_ej_page_options_footer_footer_variant_v6 show_if_ej_page_options_footer_footer_variant_v7 show_if_ej_page_options_footer_footer_variant_shop show_if_ej_page_options_footer_footer_variant_blog',
                                    
                            ) );

                            epicjungle_wp_select( array(
                                'id'            => 'ej_page_options_footer_footer_jumbotron',
                                'name'          => 'ej_page_options[footer][footer_jumbotron]',
                                'type'          => 'select',
                                'label'         => esc_html__( 'Footer Static Content', 'epicjungle-extensions' ),
                                'options'       => $static_contents,
                                'value'         => isset( $ej_page_options['footer']['footer_jumbotron'] ) ? $ej_page_options['footer']['footer_jumbotron'] : '',
                                'wrapper_class' => 'hide_if_ej_page_options_footer_footer_variant show_if_ej_page_options_footer_footer_variant_shop show_if_ej_page_options_footer_footer_variant_v8',
                            ) );
                        }

                        epicjungle_wp_upload_image( array(
                            'id'            => 'ej_page_options_footer_footer_payment_methods',
                            'name'          => 'ej_page_options[footer][footer_payment_methods]',
                            'label'         => esc_html__( 'Payment Methods', 'epicjungle-extensions' ),
                            'placeholder'   => true,
                            'value'         => ( isset( $ej_page_options['footer'] ) && isset( $ej_page_options['footer']['footer_payment_methods'] ) ) ? $ej_page_options['footer']['footer_payment_methods'] : '',
                            'wrapper_class' => 'hide_if_ej_page_options_footer_footer_variant show_if_ej_page_options_footer_footer_variant_shop',


                        ) );

                        ?><div class="hide_if_ej_page_options_footer_footer_variant show_if_ej_page_options_footer_footer_variant_blog"><?php
                            epicjungle_wp_checkbox( array(
                                'id'            => 'ej_page_options_footer_enable_newsletter_form',
                                'name'          => 'ej_page_options[footer][enable_newsletter_form]',
                                'label'         => esc_html__( 'Enable Newsletter Form', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['footer'] ) && isset( $ej_page_options['footer']['enable_newsletter_form'] ) ) ? $ej_page_options['footer']['enable_newsletter_form'] : '',
                                'class'         => 'show_hide_checkbox',
                            ) );

                            epicjungle_wp_text_input( array(
                                'id'            => 'ej_page_options_footer_epicjungle_newsletter_title',
                                'name'          => 'ej_page_options[footer][epicjungle_newsletter_title]',
                                'label'         => esc_html__( 'Newsletter Title', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['footer'] ) && isset( $ej_page_options['footer']['epicjungle_newsletter_title'] ) ) ? $ej_page_options['footer']['epicjungle_newsletter_title'] : '',
                                'wrapper_class' => 'hide_if_ej_page_options_footer_enable_newsletter_form show_if_ej_page_options_footer_enable_newsletter_form_yes',
                            ) );

                            epicjungle_wp_textarea_input( array(
                                'id'            => 'ej_page_options_footer_epicjungle_newsletter_desc',
                                'name'          => 'ej_page_options[footer][epicjungle_newsletter_desc]',
                                'label'         => esc_html__( 'Newsletter Description', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['footer'] ) && isset( $ej_page_options['footer']['epicjungle_newsletter_desc'] ) ) ? $ej_page_options['footer']['epicjungle_newsletter_desc'] : '',
                                'wrapper_class' => 'hide_if_ej_page_options_footer_enable_newsletter_form show_if_ej_page_options_footer_enable_newsletter_form_yes',
                            ) );

                            epicjungle_wp_textarea_input( array(
                                'id'            => 'ej_page_options_footer_epicjungle_newsletter_form',
                                'name'          => 'ej_page_options[footer][epicjungle_newsletter_form]',
                                'label'         => esc_html__( 'Newsletter Form', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['footer'] ) && isset( $ej_page_options['footer']['epicjungle_newsletter_form'] ) ) ? $ej_page_options['footer']['epicjungle_newsletter_form'] : '',
                                'wrapper_class' => 'hide_if_ej_page_options_footer_enable_newsletter_form show_if_ej_page_options_footer_enable_newsletter_form_yes',
                            ) );

                            epicjungle_wp_textarea_input( array(
                                'id'            => 'ej_page_options_footer_epicjungle_custom_html',
                                'name'          => 'ej_page_options[footer][epicjungle_custom_html]',
                                'label'         => esc_html__( 'Download Our App Html', 'epicjungle-extensions' ),
                                'value'         => ( isset( $ej_page_options['footer'] ) && isset( $ej_page_options['footer']['epicjungle_custom_html'] ) ) ? $ej_page_options['footer']['epicjungle_custom_html'] : '',

                            ) );

                        ?></div><?php

                        ?>

                    </div>
                </div>
            </div><?php
        }

        public static function save( $post_id, $post ) {
            if ( isset( $_POST['ej_page_options'] ) ) {
                $clean_ej_page_options = epicjungle_clean_kses_post($_POST['ej_page_options'] );
                update_post_meta( $post_id, '_ej_page_options',  serialize( $clean_ej_page_options ) );
            }   
        }
    }
}

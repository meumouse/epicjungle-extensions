<?php
/**
 * Post Types
 *
 * Registers post types and taxonomies.
 *
 * @package Mas_Static_Content/Classes
 * @version 1.0.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * Post types Class.
 */
class Mas_Static_Content_Post_Types {

    /**
     * Hook in methods.
     */
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_post_types' ), 5 );
        add_filter( 'manage_mas_static_content_posts_columns', array( __CLASS__, 'custom_mas_static_content_columns' ) );
        add_action( 'manage_mas_static_content_posts_custom_column' , array( __CLASS__, 'custom_mas_static_content_column' ), 10, 2 );
        add_filter( 'rest_api_allowed_post_types', array( __CLASS__, 'rest_api_allowed_post_types' ) );
        add_action( 'mas_static_content_after_register_post_type', array( __CLASS__, 'maybe_flush_rewrite_rules' ) );
        add_action( 'mas_static_content_flush_rewrite_rules', array( __CLASS__, 'flush_rewrite_rules' ) );
        add_filter( 'gutenberg_can_edit_post_type', array( __CLASS__, 'gutenberg_can_edit_post_type' ), 10, 2 );
    }

    /**
     * Add custom columns in mas static content post type admin panel
     */
    public static function custom_mas_static_content_columns($columns) {
        $columns_new['cb'] = $columns['cb'];
        $columns_new['title'] = $columns['title'];
        $columns_new['shortcode'] = esc_html__( 'Shortcode', 'epicjungle-extensions' );

        $columns_old = $columns;
        unset( $columns );

        $columns = array_merge( $columns_new, $columns_old );
        return $columns;
    }

    /**
     * Add the data to the custom columns for the mas static content post type
     */
    public static function custom_mas_static_content_column( $column, $post_id ) {
        switch ( $column ) {
            case 'shortcode' :
                echo '<input class="mas-static-content-shortcode-input" style="width:80%;" type="text" readonly="" onfocus="this.select()" onClick="this.select()" value="[mas_static_content id=&quot;' . $post_id . '&quot;]">';
            break;
        }
    }

    /**
     * Register core post types.
     */
    public static function register_post_types() {

        if ( ! is_blog_installed() ) {
            return;
        }

        do_action( 'mas_static_content_register_post_type' );

        // If theme support changes, we may need to flush permalinks since some are changed based on this flag.
        if ( update_option( 'current_theme_supports_mas_static_content', current_theme_supports( 'epicjungle-extensions' ) ? 'yes' : 'no' ) ) {
            update_option( 'mas_static_content_queue_flush_rewrite_rules', 'yes' );
        }

        register_post_type(
            'mas_static_content',
            apply_filters(
                'mas_static_content_register_post_type_mas_static_content',
                array(
                    'labels'              => array(
                        'name'                  => esc_html__( 'Conteúdos estáticos', 'epicjungle-extensions' ),
                        'singular_name'         => esc_html__( 'Conteúdo estático', 'epicjungle-extensions' ),
                        'all_items'             => esc_html__( 'Todos os conteúdos estáticos', 'epicjungle-extensions' ),
                        'menu_name'             => esc_html_x( 'Conteúdos estáticos', 'Admin menu name', 'epicjungle-extensions' ),
                        'add_new'               => esc_html__( 'Adicionar novo', 'epicjungle-extensions' ),
                        'add_new_item'          => esc_html__( 'Adicionar novo conteúdo estático', 'epicjungle-extensions' ),
                        'edit'                  => esc_html__( 'Editar', 'epicjungle-extensions' ),
                        'edit_item'             => esc_html__( 'Editar conteúdo estático', 'epicjungle-extensions' ),
                        'new_item'              => esc_html__( 'Novo conteúdo estático', 'epicjungle-extensions' ),
                        'view_item'             => esc_html__( 'Ver conteúdo estático', 'epicjungle-extensions' ),
                        'view_items'            => esc_html__( 'Ver conteúdos estáticos', 'epicjungle-extensions' ),
                        'search_items'          => esc_html__( 'Pesquisar conteúdo estático', 'epicjungle-extensions' ),
                        'not_found'             => esc_html__( 'Nenhum conteúdo estático encontrado', 'epicjungle-extensions' ),
                        'not_found_in_trash'    => esc_html__( 'Nenhum conteúdo estático encontrado na lixeira', 'epicjungle-extensions' ),
                        'parent'                => esc_html__( 'Conteúdo estático pai', 'epicjungle-extensions' ),
                        'featured_image'        => esc_html__( 'Imagem de conteúdo estático', 'epicjungle-extensions' ),
                        'set_featured_image'    => esc_html__( 'Definir imagem de conteúdo estático', 'epicjungle-extensions' ),
                        'remove_featured_image' => esc_html__( 'Remover imagem de conteúdo estático', 'epicjungle-extensions' ),
                        'use_featured_image'    => esc_html__( 'Use como imagem de conteúdo estático', 'epicjungle-extensions' ),
                        'insert_into_item'      => esc_html__( 'Inserir em conteúdo estático', 'epicjungle-extensions' ),
                        'uploaded_to_this_item' => esc_html__( 'Carregado para este conteúdo estático', 'epicjungle-extensions' ),
                        'filter_items_list'     => esc_html__( 'Filtrar conteúdo estático', 'epicjungle-extensions' ),
                        'items_list_navigation' => esc_html__( 'Navegação de conteúdo estático', 'epicjungle-extensions' ),
                        'items_list'            => esc_html__( 'Lista de conteúdo estático', 'epicjungle-extensions' ),
                    ),
                    'description'         => esc_html__( 'É aqui que você pode adicionar novos conteúdos estáticos ao seu site.', 'epicjungle-extensions' ),
                    'public'              => true,
                    'show_ui'             => true,
                    'map_meta_cap'        => true,
                    'publicly_queryable'  => true,
                    'exclude_from_search' => true,
                    'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
                    'rewrite'             => false,
                    'query_var'           => true,
                    'supports'            => array( 'title', 'editor', 'revisions' ),
                    'has_archive'         => false,
                    'show_in_nav_menus'   => true,
                    'show_in_menu'        => true,
                    'show_in_rest'        => true,
                    'menu_icon'           => 'dashicons-admin-post',
                )
            )
        );

        if( apply_filters( 'mas_static_content_enable_category_taxonomy', true ) ) {
            // Register Custom Taxonomy
            $labels = array(
                'name'                       => esc_html_x( 'Categorias', 'Taxonomy General Name', 'epicjungle-extensions' ),
                'singular_name'              => esc_html_x( 'Categoria', 'Taxonomy Singular Name', 'epicjungle-extensions' ),
                'menu_name'                  => esc_html__( 'Categorias', 'epicjungle-extensions' ),
                'all_items'                  => esc_html__( 'Todos os itens', 'epicjungle-extensions' ),
                'parent_item'                => esc_html__( 'Item pai', 'epicjungle-extensions' ),
                'parent_item_colon'          => esc_html__( 'Item pai:', 'epicjungle-extensions' ),
                'new_item_name'              => esc_html__( 'Nome do novo item', 'epicjungle-extensions' ),
                'add_new_item'               => esc_html__( 'Adicionar novo item', 'epicjungle-extensions' ),
                'edit_item'                  => esc_html__( 'Editar item', 'epicjungle-extensions' ),
                'update_item'                => esc_html__( 'Atualizar item', 'epicjungle-extensions' ),
                'view_item'                  => esc_html__( 'Ver item', 'epicjungle-extensions' ),
                'separate_items_with_commas' => esc_html__( 'Separe os itens com vírgulas', 'epicjungle-extensions' ),
                'add_or_remove_items'        => esc_html__( 'Adicionar ou remover itens', 'epicjungle-extensions' ),
                'choose_from_most_used'      => esc_html__( 'Escolha entre os mais usados', 'epicjungle-extensions' ),
                'popular_items'              => esc_html__( 'Itens populares', 'epicjungle-extensions' ),
                'search_items'               => esc_html__( 'Pesquisar itens', 'epicjungle-extensions' ),
                'not_found'                  => esc_html__( 'Não encontrado', 'epicjungle-extensions' ),
                'no_terms'                   => esc_html__( 'Nenhum item', 'epicjungle-extensions' ),
                'items_list'                 => esc_html__( 'Lista de itens', 'epicjungle-extensions' ),
                'items_list_navigation'      => esc_html__( 'Navegação da lista de itens', 'epicjungle-extensions' ),
            );

            $args = apply_filters( 'mas_static_content_register_taxonomy_mas_static_content_cat', array(
                'labels'                     => $labels,
                'hierarchical'               => false,
                'public'                     => true,
                'show_ui'                    => true,
                'show_admin_column'          => true,
                'show_in_nav_menus'          => true,
                'show_tagcloud'              => true,
            ) );
            register_taxonomy( 'mas_static_content_cat', array( 'mas_static_content' ), $args );
        }

        do_action( 'mas_static_content_after_register_post_type' );
    }

    /**
     * Flush rules if the event is queued.
     *
     * @since 3.3.0
     */
    public static function maybe_flush_rewrite_rules() {
        if ( 'yes' === get_option( 'mas_static_content_queue_flush_rewrite_rules' ) ) {
            update_option( 'mas_static_content_queue_flush_rewrite_rules', 'no' );
            self::flush_rewrite_rules();
        }
    }

    /**
     * Flush rewrite rules.
     */
    public static function flush_rewrite_rules() {
        flush_rewrite_rules();
    }

    /**
     * Disable Gutenberg for videos.
     *
     * @param bool   $can_edit Whether the post type can be edited or not.
     * @param string $post_type The post type being checked.
     * @return bool
     */
    public static function gutenberg_can_edit_post_type( $can_edit, $post_type ) {
        return in_array( $post_type, array( 'mas_static_content' ) ) ? false : $can_edit;
    }

    /**
     * Added video for Jetpack related posts.
     *
     * @param  array $post_types Post types.
     * @return array
     */
    public static function rest_api_allowed_post_types( $post_types ) {
        $post_types[] = 'mas_static_content';

        return $post_types;
    }
}

Mas_Static_Content_Post_Types::init();
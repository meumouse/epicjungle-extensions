<?php

// Static Content Jetpack Share Remove
if ( ! function_exists( 'epicjungle_mas_static_content_jetpack_sharing_remove_filters' ) ) {
    function epicjungle_mas_static_content_jetpack_sharing_remove_filters() {
        if( function_exists( 'sharing_display' ) ) {
            remove_filter( 'the_content', 'sharing_display', 19 );
        }
    }
}

add_action( 'mas_static_content_before_shortcode_content', 'epicjungle_mas_static_content_jetpack_sharing_remove_filters' );

if ( ! function_exists( 'epicjungle_mas_static_content_jetpack_sharing_add_filters' ) ) {
    function epicjungle_mas_static_content_jetpack_sharing_add_filters() {
        if( function_exists( 'sharing_display' ) ) {
            add_filter( 'the_content', 'sharing_display', 19 );
        }
    }
}

add_action( 'mas_static_content_after_shortcode_content', 'epicjungle_mas_static_content_jetpack_sharing_add_filters' );

// Jetpack
if ( ! function_exists( 'epicjungle_jetpack_sharing_remove_filters' ) ) {
    function epicjungle_jetpack_sharing_remove_filters() {
        if( function_exists( 'sharing_display' ) ) {
            remove_filter( 'the_content', 'sharing_display', 19 );
            remove_filter( 'the_excerpt', 'sharing_display', 19 );
        }
    }
}

add_action( 'epicjungle_single_post_before', 'epicjungle_jetpack_sharing_remove_filters', 5 );
add_action( 'woocommerce_after_single_product_summary', 'epicjungle_jetpack_sharing_remove_filters', 5 );



// Register widgets.
if ( ! function_exists ( 'epicjungle_widgets_register' )  ) {

    function epicjungle_widgets_register() {

        if ( class_exists( 'EpicJungle' ) ) {
            include_once EPICJUNGLE_EXTENSIONS_DIR . '/includes/widgets/class-epicjungle-random-posts-widget.php';
            register_widget( 'EpicJungle_Random_Posts_Widget' );
        }
    }
}

add_action( 'widgets_init', 'epicjungle_widgets_register' );



add_action( 'init', 'create_ingredients_nonhierarchical_taxonomy', 0 );
 
if ( ! function_exists ('create_ingredients_nonhierarchical_taxonomy') ) {

    function create_ingredients_nonhierarchical_taxonomy() {
 
        // Labels part for the GUI
     
        $labels = array (
            'name'                       => _x( 'Ingredients', 'taxonomy general name', 'epicjungle-extensions' ),
            'singular_name'              => _x( 'Ingredient', 'taxonomy singular name', 'epicjungle-extensions' ),
            'search_items'               => esc_html__( 'Search Ingredients', 'epicjungle-extensions' ),
            'popular_items'              => esc_html__( 'Popular Ingredients', 'epicjungle-extensions' ),
            'all_items'                  => esc_html__( 'All Ingredients', 'epicjungle-extensions' ),
            'parent_item'                => null,
            'parent_item_colon'          => null,
            'edit_item'                  => esc_html__( 'Edit Ingredient', 'epicjungle-extensions' ), 
            'update_item'                => esc_html__( 'Update Ingredient', 'epicjungle-extensions' ),
            'add_new_item'               => esc_html__( 'Add New Ingredient', 'epicjungle-extensions' ),
            'new_item_name'              => esc_html__( 'New Ingredient Name', 'epicjungle-extensions' ),
            'separate_items_with_commas' => esc_html__( 'Separate ingredient with commas', 'epicjungle-extensions' ),
            'add_or_remove_items'        => esc_html__( 'Add or remove ingredient', 'epicjungle-extensions' ),
            'choose_from_most_used'      => esc_html__( 'Choose from the most used ingredient', 'epicjungle-extensions' ),
            'menu_name'                  => esc_html__( 'Ingredients', 'epicjungle-extensions' ),
        ); 
     
        // Now register the non-hierarchical taxonomy like tag
     
        register_taxonomy('ingredient','post',array (
            'hierarchical'          => false,
            'labels'                => $labels,
            'show_ui'               => true,
            'show_in_rest'          => true,
            'show_admin_column'     => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var'             => true,
            'rewrite'               => array( 'slug' => 'ingredient' ),
        ) );

    }
}
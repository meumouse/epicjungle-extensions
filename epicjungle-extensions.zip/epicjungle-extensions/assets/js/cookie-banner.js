document.addEventListener('DOMContentLoaded', function(){
    "use strict";
    var t, c = {
            280: () => {
                var t, c = {
                    consentRememberDuration: ejcc.rememberDuration,
                    setPreferencesCookieName: ejcc.preferencesCookieName,
                    consentedCategories: ejcc.consentedCategoriesCookieName
                };

                function e() {
                    return o() || n()
                }

                function n() {
                    return 1 == ejcc.isAnalyticsShown
                }

                function o() {
                    return 1 == ejcc.isMarketingShown
                }

                function s() {
                    return 1 === ejcc.debug
                }

                function i() {
                    return "undefined" != typeof _paq
                }

                function a(t) {
                    for (var c = t + "=", e = document.cookie.split(";"), n = e.length, o = 0; o < n; o++) {
                        for (var s = e[o];
                            " " === s.charAt(0);) s = s.substring(1, s.length);
                        if (0 === s.indexOf(c)) return s.substring(c.length, s.length)
                    }
                    return null
                }

                function l(t) {
                    return JSON.parse(a(t))
                }

                function r(t, e) {
                    if (s()) return console.log("Modo de depuração ativo. Não Configurando Cookies."), console.log("Nome: " + t), console.log("Valor:"), void console.log(e);
                    var n = new Date;
                    n.setTime(n.getTime() + 24 * c.consentRememberDuration * 60 * 60 * 1e3), document.cookie = t + "=" + e + "; expires=" + n.toUTCString() + "; path=/"
                }

                function d() {
                    var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
                        e = "1";
                    t || (e = "0"), r(c.setPreferencesCookieName, e)
                }

                function g() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                    r(c.consentedCategories, JSON.stringify(t)), i() && p("analytics") && _paq.push(["setCookieConsentGiven"])
                }

                function u() {
                    return l(c.consentedCategories)
                }

                function p(t) {
                    var c = u();
                    return !(!c || c.length <= 0) && c.includes(t)
                }

                function f() {
                    var t = document.querySelector(".js--ejcc-cookie-consent-notice");
                    t && (document.body.classList.contains("ejcc-style-top") && (document.body.style.paddingTop = 0, t.style.top = -t.offsetHeight - 50 + "px"), document.body.classList.contains("ejcc-style-overlay") && (t.style.bottom = -t.offsetHeight - 50 + "px"), t.classList.add("is-closed"), document.body.classList.add("ejcc-banner-closed"), setTimeout((function() {
                        var c;
                        c = document.body, ["has-ejcc-banner"].forEach((function(t) {
                            ! function(t, c) {
                                t.classList.contains(c) && t.classList.remove(c)
                            }(c, t)
                        })), t.remove()
                    }), 750))
                }

                function k(t) {
                    return p(t) ? "ejcc-toggle-active" : ""
                }

                function v(t) {
                    var c = t.dataset.category;
                    t.classList.contains("ejcc-toggle-active") ? (! function(t) {
                        var c = u();
                        !c || c.length <= 0 || c.includes(t) && g(c = c.filter((function(c) {
                            return c !== t
                        })))
                    }(c), t.classList.remove("ejcc-toggle-active")) : (! function(t) {
                        var c = u();
                        c && c.length > 0 ? c.includes(t) || c.push(t) : c = [t], g(c)
                    }(c), t.classList.add("ejcc-toggle-active"))
                }

                function y(t) {
                    s() && console.debug(t)
                }

                function m(t) {
                    s() && console.info(t)
                }
                t = "=========== COOKIE CONSENT DEBUGGING ===========", s() && console.log(t), m("Domínios na lista negra"), m(window.YETT_BLACKLIST), m("Domínios permitidos"), m(window.YETT_WHITELIST), "1" === a(c.setPreferencesCookieName) ? (y("✅ O usuário expressou consentimento."), y("As seguintes categorias foram concedidas:"), y(l(c.consentedCategories)), document.body.classList.add("has-ejcc-consented"), i() && p("analytics") && _paq.push(["setCookieConsentGiven"])) : (y("❌ O usuário não expressou consentimento."), document.body.classList.add("has-ejcc-banner"), document.body.classList.add("ejcc-style-" + ejcc.style), function() {
                    var t = document.createElement("div");
                    if (t.id = "cookie-consent-block", t.classList.add("ejcc-cookie-consent-notice"), t.classList.add("js--ejcc-cookie-consent-notice"), t.innerHTML = '\n\t\t<div class="ejcc-cookie-consent-notice-content">\n\t\t\t<p><span>'.concat(ejcc.cookieConsentTitle, "</span>").concat(ejcc.cookieConsentText, '</p>\n\t\t\t<div class="ejcc-cookie-consent-actions">\n\t\t\t\t').concat(e() ? '<button class="ejcc-cookie-consent-necessary js--ejcc-cookie-consent-necessary">'.concat(ejcc.necessaryText, "</button>") : "", '\n\t\t\t\t<button class="ejcc-cookie-consent-close js--ejcc-cookie-consent-close close-cookie-block ejcc-cookie-consent-button">').concat(ejcc.acceptText, "</button>\n\t\t\t\t").concat(e() ? '<button class="ejcc-cookie-consent-settings-toggle js--ejcc-cookie-consent-settings-toggle">'.concat(ejcc.configureSettingsText, "</button>") : "", "\n\t\t\t</div>\n\t\t</div>\n\t\t").concat(function() {
                            if (!e()) return "";
                            var t = '<div class="ejcc-cookie-consent-settings js--ejcc-cookie-consent-settings">\n\t\t<p class="ejcc-cookie-consent-settings-title">'.concat(ejcc.settingsTitle, '</p>\n\t\t<p class="ejcc-cookie-consent-settings-intro">').concat(ejcc.settingsDescription, '</p>\n\t\t<div class="ejcc-cookie-consent-categories">\n<a href="#" class="ejcc-cookie-consent-category ejcc-toggle-disabled" data-category="necessary">\n\t\t\t\t<span class="ejcc-cookie-consent-category-info">\n\t\t\t\t\t<strong>').concat(ejcc.necessaryHeading, "</strong>\n\t\t\t\t\t<p>").concat(ejcc.necessaryDescription, '</p>\n\t\t\t\t</span>\n\t\t\t\t<span class="ejcc-cookie-consent-category-toggle">\n\t\t\t\t').concat('<span class="ejcc-cookie-consent-toggle"><span class="ejcc-cookie-consent-toggle-handle"></span></span>', "\n\t\t\t\t</span>\n\t\t\t</a>");
                            return n() && (t += '\n\t\t\t<a href="#" class="ejcc-cookie-consent-category js--ejcc-cookie-consent-toggle '.concat(k("analytics"), '" data-category="analytics">\n\t\t\t\t<span class="ejcc-cookie-consent-category-info">\n\t\t\t\t\t<strong>').concat(ejcc.analyticsHeading, "</strong>\n\t\t\t\t\t<p>").concat(ejcc.analyticsDescription, '</p>\n\t\t\t\t</span>\n\t\t\t\t<span class="ejcc-cookie-consent-category-toggle">\n\t\t\t\t').concat('<span class="ejcc-cookie-consent-toggle"><span class="ejcc-cookie-consent-toggle-handle"></span></span>', "\n\t\t\t\t</span>\n\t\t\t</a>\n\t\t")), o() && (t += '\n\t\t\t<a href="#" class="ejcc-cookie-consent-category js--ejcc-cookie-consent-toggle '.concat(k("marketing"), '" data-category="marketing">\n\t\t\t\t<span class="ejcc-cookie-consent-category-info">\n\t\t\t\t\t<strong>').concat(ejcc.marketingHeading, "</strong>\n\t\t\t\t\t<p>").concat(ejcc.marketingDescription, '</p>\n\t\t\t\t</span>\n\t\t\t\t<span class="ejcc-cookie-consent-category-toggle">\n\t\t\t\t').concat('<span class="ejcc-cookie-consent-toggle"><span class="ejcc-cookie-consent-toggle-handle"></span></span>', "\n\t\t\t\t</span>\n\t\t\t</a>\n\t\t")), t + '</div>\n\t\t<div class="ejcc-cookie-consent-settings-save">\n\t\t\t<button class="ejcc-cookie-consent-button js--ejcc-cookie-consent-settings-save-button">'.concat(ejcc.saveSettingsText, "</button>\n\t\t</div>\n</div>")
                        }(), "\n\t"), document.body.appendChild(t), document.body.classList.contains("ejcc-style-top")) {
                        var c = document.querySelector(".js--ejcc-cookie-consent-notice").offsetHeight;
                        document.body.style.paddingTop = c + "px"
                    }
                }()), s() && document.body.classList.add("ejcc-is-debugging"), document.querySelector(".js--ejcc-cookie-consent-notice") && (document.querySelector(".js--ejcc-cookie-consent-close").addEventListener("click", (function(t) {
                    t.preventDefault(), window.yett.unblock(), f(), d(), g(["necessary", "marketing", "analytics"])
                })), e() && (document.querySelector(".js--ejcc-cookie-consent-necessary").addEventListener("click", (function(t) {
                    t.preventDefault(), f(), d(), g(["necessary"])
                })), document.querySelector(".js--ejcc-cookie-consent-settings-toggle").addEventListener("click", (function(t) {
                    t.preventDefault(), document.querySelector(".js--ejcc-cookie-consent-settings").classList.toggle("is-open")
                })), document.querySelector(".js--ejcc-cookie-consent-settings-save-button").addEventListener("click", (function(t) {
                    t.preventDefault(), d(), f()
                })), document.querySelectorAll(".js--ejcc-cookie-consent-toggle").forEach((function(t) {
                    t.addEventListener("click", (function(t) {
                        t.preventDefault(), v(this)
                    }))
                }))))
            },
            133: () => {}
        },
        e = {};

    function n(t) {
        var o = e[t];
        if (void 0 !== o) return o.exports;
        var s = e[t] = {
            exports: {}
        };
        return c[t](s, s.exports, n), s.exports
    }
    n.m = c, t = [], n.O = (c, e, o, s) => {
        if (!e) {
            var i = 1 / 0;
            for (d = 0; d < t.length; d++) {
                for (var [e, o, s] = t[d], a = !0, l = 0; l < e.length; l++)(!1 & s || i >= s) && Object.keys(n.O).every((t => n.O[t](e[l]))) ? e.splice(l--, 1) : (a = !1, s < i && (i = s));
                if (a) {
                    t.splice(d--, 1);
                    var r = o();
                    void 0 !== r && (c = r)
                }
            }
            return c
        }
        s = s || 0;
        for (var d = t.length; d > 0 && t[d - 1][2] > s; d--) t[d] = t[d - 1];
        t[d] = [e, o, s]
    }, n.o = (t, c) => Object.prototype.hasOwnProperty.call(t, c), (() => {
        var t = {
            770: 0,
            108: 0
        };
        n.O.j = c => 0 === t[c];
        var c = (c, e) => {
                var o, s, [i, a, l] = e,
                    r = 0;
                if (i.some((c => 0 !== t[c]))) {
                    for (o in a) n.o(a, o) && (n.m[o] = a[o]);
                    if (l) var d = l(n)
                }
                for (c && c(e); r < i.length; r++) s = i[r], n.o(t, s) && t[s] && t[s][0](), t[s] = 0;
                return n.O(d)
            },
            e = self.webpackChunkepicjungle_cookie_consent = self.webpackChunkepicjungle_cookie_consent || [];
        e.forEach(c.bind(null, 0)), e.push = c.bind(null, e.push.bind(e))
    })(), n.O(void 0, [108], (() => n(280)));
    var o = n.O(void 0, [108], (() => n(133)));
    o = n.O(o)
})();
! function(e, t) {
    "object" == typeof exports && "undefined" != typeof module ? t(exports) : "function" == typeof define && define.amd ? define(["exports"], t) : t((e = "undefined" != typeof globalThis ? globalThis : e || self).yett = {})
}(this, (function(e) {
    "use strict";
    var t = "javascript/blocked",
        r = {
            blacklist: window.YETT_BLACKLIST,
            whitelist: window.YETT_WHITELIST
        },
        n = {
            blacklisted: []
        },
        i = (e, n) => e && (!n || n !== t) && (!r.blacklist || r.blacklist.some((t => t.test(e)))) && (!r.whitelist || r.whitelist.every((t => !t.test(e)))),
        c = function(e) {
            var t = e.getAttribute("src");
            return r.blacklist && r.blacklist.every((e => !e.test(t))) || r.whitelist && r.whitelist.some((e => e.test(t)))
        },
        s = new MutationObserver((e => {
            for (var r = 0; r < e.length; r++)
                for (var {
                        addedNodes: c
                    } = e[r], s = function(e) {
                        var r = c[e];
                        if (1 === r.nodeType && "SCRIPT" === r.tagName) {
                            var s = r.src,
                                o = r.type;
                            i(s, o) && (n.blacklisted.push([r, r.type]), r.type = t, r.addEventListener("beforescriptexecute", (function e(n) {
                                r.getAttribute("type") === t && n.preventDefault(), r.removeEventListener("beforescriptexecute", e)
                            })), r.parentElement && r.parentElement.removeChild(r))
                        }
                    }, o = 0; o < c.length; o++) s(o)
        }));

    function o(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), r.push.apply(r, n)
        }
        return r
    }

    function l(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2 ? o(Object(r), !0).forEach((function(t) {
                a(e, t, r[t])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : o(Object(r)).forEach((function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
            }))
        }
        return e
    }

    function a(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }
    s.observe(document.documentElement, {
        childList: !0,
        subtree: !0
    });
    var p = document.createElement,
        u = {
            src: Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, "src"),
            type: Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, "type")
        };
    document.createElement = function() {
        for (var e = arguments.length, r = new Array(e), n = 0; n < e; n++) r[n] = arguments[n];
        if ("script" !== r[0].toLowerCase()) return p.bind(document)(...r);
        var c = p.bind(document)(...r);
        try {
            Object.defineProperties(c, {
                src: l(l({}, u.src), {}, {
                    set(e) {
                        i(e, c.type) && u.type.set.call(this, t), u.src.set.call(this, e)
                    }
                }),
                type: l(l({}, u.type), {}, {
                    get() {
                        var e = u.type.get.call(this);
                        return e === t || i(this.src, e) ? null : e
                    },
                    set(e) {
                        var r = i(c.src, c.type) ? t : e;
                        u.type.set.call(this, r)
                    }
                })
            }), c.setAttribute = function(e, t) {
                "type" === e || "src" === e ? c[e] = t : HTMLScriptElement.prototype.setAttribute.call(c, e, t)
            }
        } catch (e) {
            console.warn("Yett: incapaz de impedir a execução de script para script src ", c.src, ".\n", 'Uma causa provável seria porque você está usando uma extensão de navegador de terceiros que corrige a função "document.createElement".')
        }
        return c
    };
    var b = new RegExp("[|\\{}()[\\]^$+*?.]", "g");
    e.unblock = function() {
        for (var e = arguments.length, i = new Array(e), o = 0; o < e; o++) i[o] = arguments[o];
        i.length < 1 ? (r.blacklist = [], r.whitelist = []) : (r.blacklist && (r.blacklist = r.blacklist.filter((e => i.every((t => "string" == typeof t ? !e.test(t) : t instanceof RegExp ? e.toString() !== t.toString() : void 0))))), r.whitelist && (r.whitelist = [...r.whitelist, ...i.map((e => {
            if ("string" == typeof e) {
                var t = ".*" + e.replace(b, "\\$&") + ".*";
                if (r.whitelist.every((e => e.toString() !== t.toString()))) return new RegExp(t)
            } else if (e instanceof RegExp && r.whitelist.every((t => t.toString() !== e.toString()))) return e;
            return null
        })).filter(Boolean)]));
        for (var l = document.querySelectorAll('script[type="'.concat(t, '"]')), a = 0; a < l.length; a++) {
            var p = l[a];
            c(p) && (n.blacklisted.push([p, "application/javascript"]), p.parentElement.removeChild(p))
        }
        var u = 0;
        [...n.blacklisted].forEach(((e, t) => {
            var [r, i] = e;
            if (c(r)) {
                for (var s = document.createElement("script"), o = 0; o < r.attributes.length; o++) {
                    var l = r.attributes[o];
                    "src" !== l.name && "type" !== l.name && s.setAttribute(l.name, r.attributes[o].value)
                }
                s.setAttribute("src", r.src), s.setAttribute("type", i || "application/javascript"), document.head.appendChild(s), n.blacklisted.splice(t - u, 1), u++
            }
        })), r.blacklist && r.blacklist.length < 1 && s.disconnect()
    }, Object.defineProperty(e, "__esModule", {
        value: !0
    })
}));